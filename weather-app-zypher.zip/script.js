async function getWeather() {
  const city = document.getElementById('city').value;
  const key = "https://api.open-meteo.com/v1/forecast?latitude=19.43&longitude=-99.13&current_weather=true";

  const res = await fetch(key);
  const data = await res.json();

  document.getElementById('result').innerHTML = `
    <h2>${city}</h2>
    <p>Temperature: ${data.current_weather.temperature}°C</p>
    <p>Wind: ${data.current_weather.windspeed} km/h</p>
  `;
}
