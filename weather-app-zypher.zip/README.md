# Weather App - Zypher
A simple weather application ready for GitHub Pages.

## How to use
1. Type a city.
2. Click search.
3. View real-time weather.

## Author
Zypher
